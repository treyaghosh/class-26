const Engine = Matter.Engine;
const World= Matter.World;
const Bodies = Matter.Bodies;

var engine, world;
var tower,ground;
var cannon;
var cannonBall;
var ball=[]
var boats=[]
var boatAnimation=[]
var boatSpriteData;
var boatSpriteSheet;
var brokenBoatAnimation=[];
var brokenboatSpriteData; 
var brokenboatSpriteSheet;

function setup(){
    var canvas = createCanvas(1200,600);
    engine = Engine.create();
    world = engine.world;
    tower= new Tower(150,350,160,310);
    ground=new Ground(0,height-1,width*2,1);
    cannon = new Cannon(180,110,100,50,-PI/4);
    var boatframes=boatSpriteData.frames
    for(var i=0; i<boatframes.length;i++){
        var pos = boatframes[i].position
        var img = boatSpriteSheet.get(pos.x,pos.y,pos.w,pos.h)
        boatAnimation.push(img)
    }
    var brokenboatframes=brokenboatSpriteData.frames
    for(var i=0; i<brokenboatframes.length;i++){
        var pos = brokenboatframes[i].position
        var img = brokenboatSpriteSheet.get(pos.x,pos.y,pos.w,pos.h)
        brokenBoatAnimation.push(img)
    }

    //cannonBall = new cannonball(cannon.x,cannon.y)
}
function preload(){
    backgroundImg=loadImage("assets/background.gif")
    boatSpriteData=loadJSON("assets/boat/boat.json")
    boatSpriteSheet=loadImage("assets/boat/boat.png")
    brokenboatSpriteData=loadJSON("assets/boat/broken_boat.json")
    brokenboatSpriteSheet=loadImage("assets/boat/broken_boat.png")
}
function draw(){
    background(250,250,250);
    image(backgroundImg,600,300,width,height);
    Engine.update(engine);
    tower.display();
    ground.display();
    cannon.display();
    showBoats();
    for(var i=0;i<ball.length;i++){
        showCannonBalls(ball[i],i)
        for(var j=0;j<boats.length;j++){
            if(ball[i]!==undefined&&boats[j]!==undefined){
                var collision=Matter.SAT.collides(ball[i].body,boats[j].body)
                if(collision.collided){
                    boats[j].remove(j)
                    Matter.World.remove(world,ball[i].body)
                    ball.splice(i,1)
                    i--
                }
            }
        }
    }
}
function keyReleased(){
    if(keyCode===DOWN_ARROW){
        ball[ball.length-1].shoot();
    }
}

function keyPressed(){
    if(keyCode===DOWN_ARROW){
       var cannonBall=new cannonball(cannon.x,cannon.y)
       ball.push(cannonBall);
    }
}

function showCannonBalls(balls,index){
    balls.display();
    if(balls.body.position.x>=width||balls.body.position.y>=height-50){
        Matter.World.remove(world,balls.body)
        ball.splice(index,1)
    }
}
function showBoats(){
    if(boats.length>0){
        if(boats.length<4&&boats[boats.length-1].body.position.x<width-300){
            var positions=[-130,-100,-120,-80]
            var position=random(positions)
            var boat= new Boat(width,height-60,200,200,position,boatAnimation)
            boats.push(boat)
        }
        for(var i=0;i<boats.length;i++){
            Matter.Body.setVelocity(boats[i].body,{x:-0.9,y:0})
            boats[i].display();
            boats[i].animate();
        }
    }
    else{
        var boat= new Boat(width,height-60,200,200,-100,boatAnimation)
        boats.push(boat)
    }
}